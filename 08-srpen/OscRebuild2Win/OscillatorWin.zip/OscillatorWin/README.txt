Oscillator win ver 0.8 > 6/2008

1. Program needs to have Java 1.5+ installed before running, go Java download @ http://www.java.com

2. Program requires usb webcam or firewire dvcam (recommended) plugged in computer before running
	When you see warning saying reconnect camera and black screen, shutdown program replug camera and try to run program again

3. during program run you can adjust your camera settings by pressing "s" key

4. in case of any other problems you can reffer bugs to christoffon@gmail.com

5. enjoy! Krystof Pesek